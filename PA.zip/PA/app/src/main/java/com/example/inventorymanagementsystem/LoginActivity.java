package com.example.inventorymanagementsystem;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {
    EditText Uname,Pass;
    Button Login;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        Uname=findViewById(R.id.emailSignIn);
        Pass=findViewById(R.id.password);
        Login=findViewById(R.id.txt_Login);


        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (Uname.getText().toString().equals("Admin") && Pass.getText().toString().equals("12345"))
                {
                    Intent intent = new Intent(LoginActivity.this, AdminDashboardActivity.class);
                    startActivity(intent);
                }
                else if (Uname.getText().toString().equals("Fabiya") && Pass.getText().toString().equals("abcd"))
                {
                    Intent intent = new Intent(LoginActivity.this, AdminDashboardActivity.class);
                    startActivity(intent);
                }
                else
                {
                    //Toast.makeText(LoginActivity.this, "Login Failed", Toast.LENGTH_SHORT).show();
                }
                LoginUser();
            }
        });
    }

    public void LoginUser()
    {
        final String f_name=Uname.getText().toString().trim();
        String u_pass=Pass.getText().toString().trim();

        if (f_name.isEmpty())
        {
            Uname.setError("It's Empty");
            Uname.requestFocus();
            return;
        }

        if(u_pass.isEmpty())
        {
            Pass.setError("It's Empty");
            Pass.requestFocus();
            return;
        }

    }
}